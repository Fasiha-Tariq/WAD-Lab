// 1. Check the type of BigInt and Symbol
let bigInt = 12345678934590n; 
let symbol = Symbol("Smile"); 

console.log(typeof bigInt); 
console.log(typeof symbol); 


// 2. Create a const object called "Product" to store the given information
const Product = {
    name: "Wheel & Engine Cleaner",
    brand: "PAKWHEELS",
    discount: "20%",
    priceBefore: 1198.00,
    priceAfter: 1198-(1198.00 * 0.2), // Applying 20% discount
    description: "Waterless & Glass Cleaner"
};

console.log(Product);

// 3. Create an object to store Instagram profile details
const myInstagramProfile = {
    username: "fasiha_tariq21",
    followers: 121,
    following: 729,
    posts: 4,
    bio: "Lost in fictional world and loving it!"
};

console.log(myInstagramProfile);

// 4. Apply Unary Operators
let a = 5;
console.log("++a =  ",++a); 

let b=7
console.log("b++ =  ",b++);
console.log("b =  ",b);

let c=9
console.log("--c =  ",--c);

let d=3
console.log("d-- =  ",d--);
console.log("d =  ",d);

// 5. Check if a number is a multiple of 3
var userInput = prompt("Enter a Number"); 
function checkMultipleOfThree(number) {
    return number % 3 === 0 ? "Multiple of 3" : "Not a multiple of 3";
}
console.log(checkMultipleOfThree(userInput));

// 6. Code to assign grades based on scores
var studentScore = prompt("Enter Marks"); 
function assignGrade(score) {
    if (score >= 80 && score <= 100) return "A";
    else if (score >= 70 && score < 80) return "B";
    else if (score >= 60 && score < 70) return "C";
    else if (score >= 50 && score < 60) return "D";
    else return "F";
}
console.log("Grade:", assignGrade(studentScore));
