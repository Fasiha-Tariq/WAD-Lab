// Loops:
//Let Array
const numbers = [12, 3, 7, 8, 10, 21, 30];
// 1. Find even numbers using for of loop in an array
const evenNumbers = [];
for (const num of numbers) {
    if (num % 2 === 0) {
        evenNumbers.push(num);
    }
}
console.log("Even Numbers:", evenNumbers);

// 2. Find max and min in an array using for of loop
let max = numbers[0];
let min = numbers[0];
for (const num of numbers) {
    if (num > max) max = num;
    if (num < min) min = num;
}
console.log("Max:", max,'\n',"Min:", min);

// 3. Convert each string in an array to uppercase using for of loop
const words = ["Apple", "Mango", "Grape", "Strawberry"];
const upperCaseWords = [];
for (const word of words) {
    upperCaseWords.push(word.toUpperCase());
}
console.log("Uppercase Words:", upperCaseWords);

// Functions:

// 4. Array of Software houses and operations
const softwareHouses = ["Google", "Microsoft", "SalesForce", "Adobe", "IBM"];
softwareHouses.shift(); // Remove first
softwareHouses.splice(2, 1, "SAP"); // Remove from middle and add new
softwareHouses.push("Oracle"); // Add at end
console.log("Updated Software Houses:", softwareHouses);

// 5. Function to count vowels in a string
function countVowels(str) {
    const vowels = "aeiouAEIOU";
    let count = 0;
    for (const char of str) {
        if (vowels.includes(char)) {
            count++;
        }
    }
    return count;
}
console.log("Vowel Count:", countVowels("Hey, Fasiha here!"));

// 6. Arrow function to count vowels
const countVowelsArrow = (str) => [...str].
filter(char => "aeiouAEIOU".includes(char)).length;
console.log("Vowel Count (Arrow):", countVowelsArrow("Arrow Function in JavaScript"));

// Methods:
// 7. Print square of each number using forEach
const nums = [3, 5, 7, 9];
nums.forEach(function(num) {
    console.log("Square of", num, ":", num * num);
});


// 8. Filter marks greater than 50
const marks = [45, 78, 30, 90, 50, 85, 40];
const filteredMarks = marks.filter(function(mark) {
    return mark > 50;
});
console.log("Marks Greater than 50:", filteredMarks);

// 9. Take input n and create an array of numbers
const n = parseInt(prompt("Enter the number of elements:"));
const newArray = [];

for (let i = 0; i < n; i++) {
    newArray.push(parseInt(prompt("Enter number " + (i + 1) + ":")));
}
console.log("User Input Array:", newArray);

// 10. Calculate product of all numbers using reduce

const numbersArray = [2, 3, 4, 5];
const product = numbersArray.reduce((acc, num) => acc * num, 1);
console.log("Product of Array:", product);
