//Type of
const cars = ["Saab", "Volvo", "BMW"];
console.log (typeof cars);

let heroes=["IronMan","Hulk","Thor","BatMan"];
console.log (typeof heroes);

let marks=[96,75,48,83,35];
console.log (typeof marks);

//for of 
let text = "Hello";
for(let char of text){
    console.log(char);
}

let number=[10,20,30,40,50];
let sum=0;
for (let val of number)
{
    sum+=val;
}
console.log("Sum= "+sum);

//Slice remove from start and end
const fruits = ["Apple", "Banana", "Cherry", "Mango", "Orange"];
const slicedFruits = fruits.slice(1, 4); 
console.log("Original Array:", fruits); 
console.log("Sliced Array:", slicedFruits); 

//Splice Modify element in an array
const colors = ["Red", "Blue", "Green", "Yellow", "Pink"];
colors.splice(1, 2, "Purple");
console.log("Updated Array:", colors);

//Shift Removes the first element
const numbers = [10, 20, 30, 40];
const firstElement = numbers.shift();
console.log("Modified Array:", numbers);
console.log("Removed Element:", firstElement);

//Unshift Adds elements at the start
const students = ["Ali", "Sara", "Fasiha"];
students.unshift("Ayesha", "Bilal"); 
console.log("Updated Array:", students);

//to String
let foodItems = ["Potato", "Tomato", "Onion", "Capsicum"];
console.log(foodItems);
console.log("To String Method: " + foodItems.toString());

//Concate 
let marvelHeroes= ["Thor", "SpiderMan", "IronMan"];
let dcHeroes = ["SuperMan", "BatMan"];
let allheroes = marvelHeroes.concat(dcHeroes);
console.log("Concate Heroes: "+allheroes) ;

// Arrow Function
const arrowSum = (a, b) => {
    console.log("Arrow Sum: " + (a + b));
};
const arrowMul = (a, b) => {
    console.log("Arrow Mul: " + (a * b));
};

// Function Calls with Arguments
arrowSum(10, 25);
arrowMul(10, 5); 

//UperCase string
console.log("For Each Loop");
let arr=["Karachi","Islamabad","Lahore"];
arr.forEach((val) => {
    console.log(val.toUpperCase());
});

//Map Methods
console.log("Map Method");
const nums = [1, 2, 3, 4, 5];

const doubledNumbers = nums.map(function(num) {
    return num * 2;
});
console.log("Original Array:", nums); 
console.log("Doubled Array:", doubledNumbers); 

//reduce method
console.log("Reduce Method");
let a = [1,2,3,4];
const output = a.reduce((res, curr)=> {
    return res+curr;
});
console.log(output);

//filter method
console.log("Filter Method");
let array = [1,2,3,4,5,6,7];
let evenarr = array.filter((val) =>{
    return val %2 ==0;
});
console.log(evenarr);






