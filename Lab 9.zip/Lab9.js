const button = document.getElementById("toggleButton");

button.addEventListener("click", function () {
  document.body.classList.toggle("dark-mode");
});

button.onmouseover = function () {
  button.classList.add("hover-effect");
};

button.onmouseout = function () {
  button.classList.remove("hover-effect");
};
