//Task 1
function changeClass() {
      let element = document.getElementById("myPara");
      console.log("Old class:", element.className);
      element.className = "newClass";
      console.log("New class:", element.className);
    }

//Task 2
  let button = document.createElement("button");
  button.id = "logIn";
  button.innerText = "Log In";
  //Button Styling
  button.style.backgroundColor = "rgb(161, 192, 23)";
  button.style.color = "black";
  button.style.fontFamily = "TimesNewRoman";
  button.style.fontWeight = "bold"
  button.style.fontSize = "18px"
  button.style.padding = "10px 20px";
  button.style.border = "none";
  //Button before the <body> tag
  document.documentElement.insertBefore(button, document.body);
  
//Task 3
  function addNewStyle() {
      let p = document.getElementById("myParagraph");
      p.classList.add("extra-style");
    }